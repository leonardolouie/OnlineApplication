
@extends('front.application.inc.master')
@section('title', 'Success')
@section('content')
 
 <div class="container"> 
 <h1>Thank you for submitting your information.... </h1>
 <a href="https://www.philpowercorp.com/">Click this to redirect to main site</a>
 </div>

@endsection