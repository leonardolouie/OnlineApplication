<?php $__env->startSection('title', 'Success'); ?>
<?php $__env->startSection('content'); ?>
 
 <div class="container"> 
 <h1>Thank you for submitting your information.... </h1>
 <a href="https://www.philpowercorp.com/">Click this to redirect to main site</a>
 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.application.inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PearlPay Laptop 2\Documents\GitHub\OnlineApplication\resources\views/front/application/success.blade.php ENDPATH**/ ?>