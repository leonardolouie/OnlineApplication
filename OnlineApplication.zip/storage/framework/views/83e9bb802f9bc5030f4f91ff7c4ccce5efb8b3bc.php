<?php $__env->startSection('title', 'Phil Power Corp  Online Application'); ?>
<?php $__env->startSection('content'); ?>



    <form method="POST" action="/application/save" id="application-form">
        
      
        <?php echo csrf_field(); ?>
        
        <div class="container mt-5 mb-5"> 
            <h1 class="h2">ONLINE APPLICATION</h1>
        </div>
        
        <div class="container mt-5 mb-5">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
        <div class="container"> 
            <div class="row"> 
            <div class="col-lg-6"> 
                <?php echo $__env->make('front.application.components.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <div class="mt-5 mb-5"> 
                    <h2 class="h4">PERSONAL INFORMATION</h1>
                </div>
                
                <?php echo $__env->make('front.application.components.personal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-lg-6"> 
                <div class="mb-5"> 
                    <h2 class="h4">IN CASE OF EMERGENCY</h1>
                </div>
                <?php echo $__env->make('front.application.components.incase-emergency', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 <div class="mb-5"> 
                    <h2 class="h4">EDUCATIONAL BACKGROUND</h1>
                 </div>
                <?php echo $__env->make('front.application.components.educational-background', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="mb-5"> 
                    <h2 class="h4">EMPLOYMENT HISTORY</h1>
                </div>
                <?php echo $__env->make('front.application.components.employment-history', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="mb-5"> 
                    <h2 class="h4">CHARACTER REFERENCE</h1>
                </div>
                <?php echo $__env->make('front.application.components.character-reference', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="mb-5">
                <button  type="submit" id="btn-submit" class="btn btn-primary">Submit Application</button>
                </div>
            </div>
          </div>
        </div>
       
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.application.inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PearlPay Laptop 2\Documents\GitHub\OnlineApplication\resources\views/front/application/index.blade.php ENDPATH**/ ?>